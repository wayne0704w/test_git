package sungweiw_CSCI201L_Lab1;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		String s = "Hello World!";
		s = null;
		s.length();
	}

}
